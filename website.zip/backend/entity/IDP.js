// ENTITY: Interior Design Project. Each IDP has exactly 1 style and 1..* types,
// both taken from the preset list in database/tags.txt.
const { loadPresetTags } = require('../../database/presetTags');

class IDP {
  /** @param loadPreset  returns { style: {name: keywords[]}, type: {...} }; tests pass a small fixed list */
  constructor(db, loadPreset = loadPresetTags) {
    this.db = db;
    this.loadPreset = loadPreset;
  }

  /**
   * @param {number} designerId
   * @param {{title, description, budget, houseSize, duration, visibility, style, type}} idpData  already validated
   */
  createIDP(designerId, idpData) {
    const result = this.db
      .prepare(
        `INSERT INTO idp (designer_id, title, description, budget, house_size, duration, visibility, style, type)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        designerId,
        idpData.title,
        idpData.description,
        idpData.budget,
        idpData.houseSize,
        idpData.duration,
        idpData.visibility,
        idpData.style,
        JSON.stringify(idpData.type)
      );
    return this.getIDPById(Number(result.lastInsertRowid));
  }

  getIDPById(idpId) {
    const row = this.db.prepare(`${IDP.SELECT} WHERE i.id = ?`).get(idpId);
    return row ? IDP.fromRow(row) : null;
  }

  incrementViewCount(idpId) {
    const result = this.db.prepare(
      'UPDATE idp SET view_count = view_count + 1 WHERE id = ?'
    ).run(Number(idpId));
    return result.changes > 0;
  }

  getIDPsByDesigner(designerId) {
    return this.db
      .prepare(`${IDP.SELECT} WHERE i.designer_id = ? ORDER BY i.created_at DESC, i.id DESC`)
      .all(designerId)
      .map(IDP.fromRow);
  }

  /** All projects for the User Admin inventory, including suspended/private projects. */
  getAllIDPsForAdmin() {
    return this.db.prepare(`SELECT i.*, a.username AS designer_name, a.is_active AS designer_is_active,
      (SELECT m.id FROM idp_media m WHERE m.idp_id=i.id AND m.mime_type LIKE 'image/%' ORDER BY m.id LIMIT 1) AS cover_media_id
      FROM idp i JOIN user_account a ON a.id=i.designer_id
      ORDER BY i.created_at DESC, i.id DESC`).all().map((row) => ({
      ...IDP.fromRow(row),
      designerIsActive: Boolean(row.designer_is_active),
    }));
  }

  setSuspended(idpId, suspended) {
    const result = this.db.prepare('UPDATE idp SET is_suspended=? WHERE id=?')
      .run(suspended ? 1 : 0, Number(idpId));
    return result.changes > 0;
  }

  canReactivate(idpId) {
    return Boolean(this.db.prepare(`SELECT 1 FROM idp i JOIN user_account a ON a.id=i.designer_id
      WHERE i.id=? AND a.is_active=1`).get(Number(idpId)));
  }

  /** Favourites are removed by ON DELETE CASCADE; contact requests keep their history without the IDP. */
  deleteIDP(idpId) {
    this.db.prepare('UPDATE contact_request SET idp_id = NULL WHERE idp_id = ?').run(idpId);
    this.db.prepare('DELETE FROM idp WHERE id = ?').run(idpId);
  }

  getLatestIDPs(limit = 12) {
    return this.db
      .prepare(`${IDP.SELECT} WHERE i.visibility = 'public' AND i.is_suspended = 0 AND a.is_active = 1 ORDER BY i.created_at DESC, i.id DESC LIMIT ?`)
      .all(limit)
      .map(IDP.fromRow);
  }

  // ---------- #23 preset styles / types ----------

  /** @param {'style' | 'type'} category */
  getTagsByType(category) {
    return Object.keys(this.loadPreset()[category] ?? {});
  }

  /** Keeps only preset names, in the given order, without duplicates. */
  findByNames(names) {
    if (!Array.isArray(names)) return [];
    const preset = this.loadPreset();
    const known = (name) => Object.hasOwn(preset.style, name) || Object.hasOwn(preset.type, name);
    return [...new Set(names)].filter((name) => typeof name === 'string' && known(name));
  }

  /**
   * #23 fallback when the AI service fails: names whose name or keywords appear in the
   * description (whole words, any case). Best match first = most keywords found.
   */
  matchByKeywords(description) {
    if (typeof description !== 'string' || !description.trim()) return [];
    const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const appears = (word) => new RegExp(`\\b${escape(word)}\\b`, 'i').test(description);
    const preset = this.loadPreset();
    return [...Object.entries(preset.style), ...Object.entries(preset.type)]
      .map(([name, keywords]) => {
        const words = new Set([name, ...keywords].map((w) => w.toLowerCase()));
        return { name, hits: [...words].filter(appears).length };
      })
      .filter((m) => m.hits > 0)
      .sort((a, b) => b.hits - a.hits || a.name.localeCompare(b.name))
      .map((m) => m.name);
  }

  /**
   * #1 Recommended IDPs. Public IDPs that share at least one style or type name with
   * tagPreferences (a Map of name -> count), excluding IDPs already in customer's favourites.
   */
  findSimilarIDPs(tagPreferences, favouriteIDPs) {
    const names = [...tagPreferences.keys()];
    if (names.length === 0) return [];
    const favouriteIds = favouriteIDPs.map((f) => f.id);
    const marks = (list) => list.map(() => '?').join(', ');

    let sql = `${IDP.SELECT}
       WHERE i.visibility = 'public' AND i.is_suspended = 0 AND a.is_active = 1
         AND (i.style IN (${marks(names)})
              OR EXISTS (SELECT 1 FROM json_each(i.type) WHERE value IN (${marks(names)})))`;
    const params = [...names, ...names];
    if (favouriteIds.length > 0) {
      sql += ` AND i.id NOT IN (${marks(favouriteIds)})`;
      params.push(...favouriteIds);
    }
    sql += ' ORDER BY i.created_at DESC, i.id DESC';
    return this.db.prepare(sql).all(...params).map(IDP.fromRow);
  }

  /**
   * #2 Public IDPs matching every criterion that is given. null means "not selected".
   * Budget and house size ranges are inclusive, 
   * duration and style (styleTag) must match exactly.
   */
  findByFilters(minBudget, maxBudget, minHouseSize, maxHouseSize, duration, styleTag) {
    const conditions = ["i.visibility = 'public'", 'i.is_suspended = 0', 'a.is_active = 1'];
    const params = [];
    const add = (condition, value) => {
      if (value === null || value === undefined) return;
      conditions.push(condition);
      params.push(value);
    };
    add('i.budget >= ?', minBudget);
    add('i.budget <= ?', maxBudget);
    add('i.house_size >= ?', minHouseSize);
    add('i.house_size <= ?', maxHouseSize);
    add('i.duration = ?', duration);
    add('i.style = ?', styleTag);

    return this.db
      .prepare(`${IDP.SELECT} WHERE ${conditions.join(' AND ')} ORDER BY i.created_at DESC, i.id DESC`)
      .all(...params)
      .map(IDP.fromRow);
  }

  static fromRow(row) {
    return {
      id: row.id,
      idpId: row.id,
      designerId: row.designer_id,
      designerName: row.designer_name,
      title: row.title,
      description: row.description,
      budget: row.budget,
      houseSize: row.house_size,
      duration: row.duration,
      visibility: row.visibility,
      style: row.style,
      type: JSON.parse(row.type),
      viewCount: Number(row.view_count ?? 0),
      isSuspended: Boolean(row.is_suspended),
      createdAt: row.created_at,
      coverMediaId: row.cover_media_id,
    };
  }
}

IDP.SELECT = `
  SELECT i.*, a.username AS designer_name,
    (SELECT m.id FROM idp_media m WHERE m.idp_id = i.id AND m.mime_type LIKE 'image/%' ORDER BY m.id LIMIT 1) AS cover_media_id
    FROM idp i
    JOIN user_account a ON a.id = i.designer_id`;

module.exports = IDP;
